document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    const telegramBotToken = 'YOUR_BOT_TOKEN';
    const chatId = 'YOUR_CHAT_ID';
    const text = `Pesan baru dari:\nNama: ${name}\nEmail: ${email}\nPesan: ${message}`;

    fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(text)}`)
        .then(response => response.json())
        .then(data => {
            if (data.ok) {
                alert('Pesan berhasil dikirim!');
                document.getElementById('contactForm').reset();
            } else {
                alert('Gagal mengirim pesan!');
            }
        })
        .catch(error => alert('Terjadi kesalahan!'));
});
